package Exercicio;

public class Caminhao extends Veiculo {
    public Caminhao(float toneladas, int alturaMax, int comprimento, float quilos, float velocMaxKm, double preco) {
        super(quilos, velocMaxKm, preco);
        this.alturaMax = alturaMax;
        this.toneladas = toneladas;
        this.comprimento = comprimento;

    }

    private float toneladas;
    private int alturaMax;
    private int comprimento;

    // setter getter//
    public void setAlturaMax(int alturaMax) {
        this.alturaMax = alturaMax;
    }

    public void setComprimento(int comprimento) {
        this.comprimento = comprimento;
    }

    public void setToneladas(float toneladas) {
        this.toneladas = toneladas;
    }

    public int getAlturaMax() {
        return alturaMax;
    }

    public int getComprimento() {
        return comprimento;
    }

    public float getToneladas() {
        return toneladas;
    }
    // setter getter//

    public void mostrarDados() {
        System.out.println("-Mostra Dados Veiculo-");
        System.out.println("Toneladas  | " + getToneladas());
        System.out.println("Comprimento| " + getComprimento());
        System.out.println("AlturaMax  | " + getAlturaMax());
        System.out.println("Quilos     | " + getQuilos());
        System.out.println("VelocMaxKm | " + getVelocMaxKm());
        System.out.println("preco      | " + getPreco());
        System.out.println("----------------------");
    }
}

/*
 * Crie a subclasse Caminhao usando a superclasse Veiculo como base. Inclua os
 * atributos toneladas (carga máxima, float), alturaMax (int) e comprimento
 * (int). E sobrescreva o construtor e o método mostrarDados para mostrar os
 * dados na tela
 */