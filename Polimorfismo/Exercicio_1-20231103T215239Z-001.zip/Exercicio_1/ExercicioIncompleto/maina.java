package Exercicio;

import java.util.Scanner;

public class maina {
    public static void main(String args[]){
        int op = 3;
        Veiculo veiculo;
        Scanner input = new Scanner(System.in);
        do{
            System.out.println("-MENU-");
            System.out.println("1-Cadastrar");
            System.out.println("    |P-Passeio");
            System.out.println("    |C-Caminhão");
            System.out.println("2-imprimir Dados");
            System.out.println("0-Sair");
            System.out.println("-------------");
            System.out.print("OPÇÂO =");
            op = input.nextInt();
            switch (op) {
                case 1:
                    String a;
                    System.out.println("op1");
                    input.nextLine();
                    a = input.nextLine();
                    if (a.equalsIgnoreCase("C")) {
                        System.out.println("1");
                    }else if (a.equalsIgnoreCase("P")) {
                        System.out.println("2");
                    }else{
                        System.out.println("3");
                    }
                    break;
            
                default:
                    break;
            }
        }while(op != 0);

        
    }

}

/*
 * O programa deve fornecer um menu com opções (como o apresentado a seguir)
 * para serem escolhidas pelo usuário:
 * 1 – Cadastrar Veículo
 * P – Passeio
 * C – Caminhão
 * 2 – Imprimir Dados
 * 0 - Sair
 * Dependendo da opção selecionada, o programa executa o método do objeto
 * informado. Use o polimorfismo
 */