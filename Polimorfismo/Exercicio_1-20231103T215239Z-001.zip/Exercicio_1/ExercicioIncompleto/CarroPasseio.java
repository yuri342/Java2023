package Exercicio;

public class CarroPasseio extends Veiculo {
    private String cor;
    private String modelo;

    //getter e setter//
    public String getCor() {
        return cor;
    }
    public String getModelo() {
        return modelo;
    }
    public void setCor(String cor) {
        this.cor = cor;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    //getter e setter//
    public CarroPasseio(String cor, String modelo, float quilos, float velocMaxKm, double preco) {
        super(quilos, velocMaxKm, preco);
        this.cor = cor;
        this.modelo = modelo;
    }

    public void mostrarDados() {
        System.out.println("-Mostra Dados Veiculo-");
        System.out.println("Modelo     | " + getModelo());
        System.out.println("Cor        | " + getCor());
        System.out.println("Quilos     | " + getQuilos());
        System.out.println("VelocMaxKm | " + getVelocMaxKm());
        System.out.println("preco      | " + getPreco());
        System.out.println("----------------------");
    }
}

/*
 * Crie a subclasse CarroPasseio usando a superclasse Veiculo como base. Inclua
 * os atributos cor (String) e modelo (String). E sobrescreva o construtor da
 * classe Veiculo e o método mostrarDados para mostrar os dados na tela.
 */