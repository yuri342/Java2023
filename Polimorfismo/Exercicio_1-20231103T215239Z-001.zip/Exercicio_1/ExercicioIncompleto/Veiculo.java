package Exercicio;

public class Veiculo {
    private float quilos;
    private float velocMaxKm;
    private double preco;

    // getters setters//
    public double getPreco() {
        return preco;
    }

    public float getQuilos() {
        return quilos;
    }

    public float getVelocMaxKm() {
        return velocMaxKm;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setQuilos(float quilos) {
        this.quilos = quilos;
    }

    public void setVelocMaxKm(float velocMaxKm) {
        this.velocMaxKm = velocMaxKm;
    }

    // getters setters//
    public Veiculo(float quilos, float velocMaxKm, double preco) {
        this.preco = preco;
        this.velocMaxKm = velocMaxKm;
        this.quilos = quilos;
    }

    public void mostrarDados() {
        System.out.println("-Mostra Dados Veiculo-");
        System.out.println("Quilos     | " + getQuilos());
        System.out.println("VelocMaxKm | " + getVelocMaxKm());
        System.out.println("preco      | " + getPreco());
        System.out.println("----------------------");
    }
}

/*
 * Implemente a classe Veiculo com os atributos: peso em quilos, velocMax em
 * Km/h e preco em R$. Crie o construtor da classe que carregue todos os
 * atributos e o método mostrarDados para imprimir os dados na tela.
 */