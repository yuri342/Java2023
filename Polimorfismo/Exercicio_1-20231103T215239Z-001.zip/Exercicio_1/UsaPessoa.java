package Exercicio_1;

public class UsaPessoa {
    Pessoa pessoa1 = new Pessoa("Mário", "Lopes");
    Funcionario pessoa2 = new Funcionario("Lucas", "Mendes", 2000.00);
    Professor pessoa3 = new Professor("Rafael", "Lira", 1000.00);
}

/*
 * d) Crie uma classe UsaPessoa que instancia os seguintes objetos:
 * pessoa1 (Pessoa) pessoa2 (Funcionário) pessoa3 (Professor)
 * Nome: Mário
 * Sobrenome: Lopes
 * Nome: Lucas
 * Sobrenome: Mendes
 * Salário: 2000.00
 * Nome: Rafael
 * Sobrenome: Lira
 * Salário: 1000.00
 */